export function login() {
  return `
  <section>
    <div class="login-container">
        <div class="login-card">
            <div class="logo-circle">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5zm0 18c-3.87-.91-7-5.05-7-9V8.31l7-3.89 7 3.89V11c0 3.95-3.13 8.09-7 9z"/>
                    <path d="M8 12l-2-2-1.41 1.41L8 14.83l8-8L14.59 5.42z"/>
                </svg>
            </div>
            
            <h2 class="text-center mb-2">RestorApp</h2>
            <p class="text-center text-muted mb-4">Login to your account</p>
            
            <form>
                <div class="form-group">
                    <label for="fullName" class="form-label">Full Name</label>
                    <div class="input-group">
                        <svg class="input-icon" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                        </svg>
                        <input type="text" class="form-control" id="fullName" placeholder="e.g. John Doe">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email Address</label>
                    <div class="input-group">
                        <svg class="input-icon" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2zm13 2.383-4.758 2.855L15 11.114v-5.73zm-.034 6.878L9.271 8.82 8 9.583 6.728 8.82l-5.694 3.44A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.739zM1 11.114l4.758-2.876L1 5.383v5.73z"/>
                        </svg>
                        <input type="email" class="form-control" id="email" placeholder="name@example.com">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="role" class="form-label">Select Role</label>
                    <div class="input-group">
                        <svg class="input-icon" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M6.5 1A1.5 1.5 0 0 0 5 2.5V3H1.5A1.5 1.5 0 0 0 0 4.5v8A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-8A1.5 1.5 0 0 0 14.5 3H11v-.5A1.5 1.5 0 0 0 9.5 1h-3zm0 1h3a.5.5 0 0 1 .5.5V3H6v-.5a.5.5 0 0 1 .5-.5zm1.886 6.914L15 7.151V12.5a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5V7.15l6.614 1.764a1.5 1.5 0 0 0 .772 0zM1.5 4h13a.5.5 0 0 1 .5.5v1.616L8.129 7.948a.5.5 0 0 1-.258 0L1 6.116V4.5a.5.5 0 0 1 .5-.5z"/>
                        </svg>
                        <select class="form-control" id="role">
                            <option selected>User</option>
                            <option value="1">Admin</option>
                            <option value="2">Manager</option>
                        </select>
                    </div>
                </div>
                
                <button type="submit" class="btn-sign-in">Sign In</button>
                
                <p class="text-center">
                    Don't have an account? <a href="#" class="sign-up-link">Sign up</a>
                </p>
            </form>
        </div>
        
        <p class="footer-text">RestorApp Academic Simulation</p>
    </div>
</section>
   `;
}


